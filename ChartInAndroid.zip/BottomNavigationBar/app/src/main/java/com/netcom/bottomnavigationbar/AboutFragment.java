package com.netcom.bottomnavigationbar;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager2.widget.ViewPager2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class AboutFragment extends Fragment {

    TabLayout tabLayoutAbout ;
    FrameLayout viewPager2;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_about, container, false);

//        ArrayList<String> arrayList = new ArrayList<>();


        tabLayoutAbout = view.findViewById(R.id.tabLayoutId);
        tabLayoutAbout.addTab(tabLayoutAbout.newTab().setText("Physics"));
        tabLayoutAbout.addTab(tabLayoutAbout.newTab().setText("Maths"));
        tabLayoutAbout.addTab(tabLayoutAbout.newTab().setText("Subject 1"));
        tabLayoutAbout.addTab(tabLayoutAbout.newTab().setText("Subject 2"));
        tabLayoutAbout.addTab(tabLayoutAbout.newTab().setText("Subject 3"));


        tabLayoutAbout.setTabGravity(TabLayout.GRAVITY_FILL);
        viewPager2 = view.findViewById(R.id.SubjectContainerId);

        getFragmentManager().beginTransaction().replace(R.id.SubjectContainerId, new PhysicsFragment()).commit();
        TabLayout.Tab tab = tabLayoutAbout.getTabAt(0);
        tab.select();


//        prepareViewPager(viewPager2 , arrayList);

        tabLayoutAbout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                Fragment fragment = null;

                switch (tab.getPosition()) {
                    case 0:
                        fragment = new PhysicsFragment();
                        break;

                    case 1:
                        fragment = new MathsFragment();
                        break;

                    case 2:{
                        fragment = new PhysicsFragment();
                        break;
                    }
                    case 3:{
                        fragment = new MathsFragment();
                        break;
                    }
                    case 4:
                        fragment = new PhysicsFragment();
                        break;

                }

                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.SubjectContainerId, fragment);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
                ft.commit();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });

        return view;
    }

}


/*


    private void prepareViewPager(ViewPager2 viewPager2, ArrayList<String> arrayList) {

        MainAdapter adapter = new MainAdapter(getFragmentManager());

//        viewPager2.setAdapter(adapter);

    }
    private class MainAdapter extends FragmentPagerAdapter {

        ArrayList<String> arrayList = new ArrayList<>();
        List<Fragment> fragments = new ArrayList<>();

        public void addFragment(Fragment fragment , String title){
            arrayList.add(title);
            fragments.add(fragment);
        }

        public MainAdapter(@NonNull FragmentManager fm) {
            super(fm);

        }

        @NonNull
        @Override
        public Fragment getItem(int position) {

            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return arrayList.get(position);

        }
    }


 */
