package com.netcom.bottomnavigationbar;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

public class PhysicsFragment extends Fragment {
    TextView qn_ans , vdo_watch , points;
    PieChart pieChart ;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_physics, container, false);
        pieChart = view.findViewById(R.id.pieChartPhy);
        qn_ans = view.findViewById(R.id.qa_phy);
        vdo_watch = view.findViewById(R.id.vw_phy);
        points = view.findViewById(R.id.pe_phy);

        int a = Integer.valueOf(qn_ans.getText().toString());
        int b = Integer.valueOf(vdo_watch.getText().toString());
        int c = Integer.valueOf(points.getText().toString());

        ArrayList<PieEntry> NoOfEmp = new ArrayList<>();
        NoOfEmp.add(new PieEntry(a, 1));
        NoOfEmp.add(new PieEntry(b, 2));
        NoOfEmp.add(new PieEntry(c, 3));

        PieDataSet dataSet = new PieDataSet(NoOfEmp, "Physics Analysis");

        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        pieChart.animateXY(1000, 1000);

        return view;
    }
}

/*


        List NoOfEmp = new ArrayList();
        NoOfEmp.add(new Entry(85 , 0));
        NoOfEmp.add(new Entry(75 , 1));
        NoOfEmp.add(new Entry(95 , 2));

        PieDataSet dataSet = new PieDataSet(NoOfEmp, "Physics Analysis ");


        List<String> year = new ArrayList();
        year.add("Qn Ans");
        year.add("Video");
        year.add("Points");

        String yearStr = "2010";

        PieDataSet data = new PieDataSet(NoOfEmp , yearStr);

        PieData pieData = new PieData();
        pieData.setDataSet(data);

        pieChart.setData(pieData);
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        pieChart.animateXY(5000, 5000);


 */
